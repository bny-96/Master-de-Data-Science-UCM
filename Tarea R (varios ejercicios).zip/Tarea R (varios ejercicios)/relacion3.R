
#Relacion 3. Alumno: PABLO BENAYAS



library(stringr) 



# 1. Crear una funci�n que calcule la suma de dos n�meros 
sumOfTwoNumbers <- function(x,y) {
  return(x+y)
}
sumOfTwoNumbers(3,5)



# 2. Crear una funci�n que devuelva TRUE si un n�mero est� en un vector. Deber� recibir como 
# argumentos el vector y el n�mero. Prueba: mi.func(c(5,8,34),6) 
#     a. Resolver el ejercicio usando un bucle while dentro de la funci�n 
checkNumber <- function(vector, number) {
  count <- 1
  check <- 0
  while (count <= length(vector)) {
    if (vector[count] == number) {
      check <- 1
      return(TRUE)
    }  
    count <- count + 1
  }
  if (check == 0) {
    return(FALSE)
  }
}
checkNumber(c(5,8,34),6) 
#     b. Con un bucle for dentro de la funci�n 
checkNumber <- function(vector, number) {
  count <- 0
  for (element in vector) {
    if (element == number) {
      count <- count + 1
    }
  }
  if (count > 0) {
    return(TRUE)
  } else {
    return(FALSE)
  }
}
checkNumber(c(5,8,34),6) 
#     c. Con el operador %in% dentro de la funci�n 
checkNumber <- function(vector, number) {
  return(number %in% vector)
} 
checkNumber(c(5,8,34),6)



# 3. Crear una funci�n que dado un data frame, imprima por pantalla el nombre y 
# tipo de cada columna.
df <- data.frame(A=c(21,13,30), B=c('b','z','u')) 

namesTypes <- function(dataframe) {
  print(sapply(c(names(df)), function(x) class(df[,x])) )
}
namesTypes(df)




# 4. Crear una funci�n que dado un entero calcule devuelva sus divisores en un vector. Se 
# puntuar� c�mo de optimizada est�. �Es adecuado usar un bucle? 
divisors <- function(number) {
  potentialDivisors <- 1:number
  return(potentialDivisors[number%%potentialDivisors==0])
}
divisors(20) 
#     a. Invocar a esta funci�n sobre una lista de enteros del 1 al 20 sin usar un bucle 
#     sino sapply. �Qu� tipo devuelve? �Por qu�? 
sapply(as.list(1:20), divisors) 
        #Al pasarle una lista a 'sapply', el output sera otra
        #nueva lista donde cada elemento ser� los divisores de cada
        #numero de la input lista.

#     b. Incorporar a la funci�n anterior un argumento adicional que indique cu�ntos divisores 
#     queremos calcular como m�ximo. Volver a invocarla usando sapply sobre los enteros del 1 
#     al 50 con un m�ximo de 5 divisores. �Qu� tipo devuelve ahora? �Por qu� es diferente al 
#     anterior? 
divisors <- function(number, max_values) {
  potentialDivisors <- 1:number
  divisors <- potentialDivisors[number%%potentialDivisors==0]
  return(divisors[1:min(max_values, length(divisors))])
}

divisors(20,3)
sapply(1:50, divisors, max_values=5) 
      #Sigue devolviendo una lista (ver como lo funci�n ha sido
      #definida)




# 5. Crear una funci�n que reciba un factor y un booleano con valor por defecto FALSE. 
# Si el argumento booleano es TRUE, primero quitar� los niveles no usados del factor. 
# Adem�s de lo anterior, independientemente del valor del booleano, debe renombrar todos 
# los niveles del factor para que la primera letra de cada nivel sea may�scula. La funci�n 
# debe devolver el objeto factor modificado (no los nombres sino los datos modificados, 
# como objeto factor). 
function5 <- function(factor, boolean=FALSE) {
  if (boolean==FALSE) {
    levels(factor) <- sapply(levels(factor), 
                             function(x) paste(toupper(str_sub(x,1,1)), 
                                               str_sub(x,2,nchar(x)), sep=''))                              
    return(factor)
    
  } else{
    factor <- droplevels(factor)
    levels(factor) <- sapply(levels(factor), 
                             function(x) paste(toupper(str_sub(x,1,1)), 
                                               str_sub(x,2,nchar(x)), sep=''))  
    return(factor)
    
  }
  
}
studies = factor(c("medium", "low", "medium", "low"), levels =c("low", "medium", "high"))                                
function5(studies, TRUE)



# 6. Escribir un bucle repeat{} que imprima todos los n�meros pares entre 2 y 10. Repetir 
# el ejercicio con sapply. 
output <- c()
values <- 2:10
repeat {
  for (element in values) {
    if (element %% 2 == 0) {
      output <- c(output, element)
    }
  }
  break
} 
output
# b) Dise�ar una funci�n para este segundo caso para pasarla como 
# argumento a sapply. La funci�n no tiene el mismo c�digo que para repeat ya que debe procesar 
# un solo elemento, y sapply la invocar� autom�ticamente para la lista 2:10. Invocarla con 
# sapply(2:10, FUN = mifunc).
unlist(sapply(2:10, function(x) x[x%%2 == 0])) 



# 7. Escribir un bucle for() que imprima los cuatro primeros n�meros de la 
# secuencia: x = c(7, 4, 3, 8, 9, 25)
x <- c(7, 4, 3, 8, 9, 25)
output <- c()

for (i in 1:length(x)) {
  if (i <= 4) {
    output <- c(output, x[i])
  }
}
output