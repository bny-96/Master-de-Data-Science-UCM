
#Relacion 2. Alumno: PABLO BENAYAS



library(stringr) 


# 1. Crear el siguiente data frame. Una vez creado, invertir el sexo para todos los
# individuos.
Age=c(25,31,23,52,76,49,26)
Height=c(177,163,190,179,163,183,164) 
Weight=c(57,69,83,75,70,83,53)
Sex=c("F","F","M","M","F","M","F") 

df <- data.frame(Age, Height, Weight, Sex, 
                 row.names=c('Alex', 'Lilly', 'Mark', 'Oliver', 'Martha', 'Lucas', 'Caroline'))
df$Sex <- ifelse(df$Sex=='F','M','F')
df



# 2. Crear el siguiente data frame, asegur�ndose de que Working es una columna de
# tipo factor.
# a. A�adir este data frame al anterior por la derecha como una nueva
# columna.
working <- data.frame(Working=factor(c('Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'Yes')))
df_new <- cbind(df,working) 
df_new
# b. �Cu�ntas filas y columnas tiene el nuevo data frame? Comprobarlo
dim(df)
dim(df_new) 
# c. �De qu� clase es cada columna? Comprobarlo.
sapply(names(df_new), function(x) class(df_new[,x]))



# 3. Entre los datasets presentes en R se encuentra uno llamado state.center.
# Comprobar de qu� clase es dicha variable, y convertirla a data.frame en una
# nueva variable llamada "state.center.df".
class(state.center)
state.center.df <- as.data.frame(state.center)



# 4. Crear un data frame a partir de tres vectores de 10 elementos aleatorios entre -1
# y 1. Elegir nombres para las columnas y asign�rselos. Ordenar todo el data
# frame en base a la primera columna.
v1 <- runif(10,-1,1)
v2 <- runif(10,-1,1)
v3 <- runif(10,-1,1)

df_3 <- data.frame(a=v1, b=v2, c=v3) 
df_3[order(df_3$a) , ]



# 5. Crear un data frame a partir de una matriz bidimensional de 10 filas y 5
# columnas de n�meros aleatorios de una normal est�ndar.
values <- runif(5*10,-1,1)
df_5=data.frame(array(values, dim = c(10,5)))
# a. Cambiar los nombres de las filas para que cada fila se llame id_i siendo i
# el n�mero de fila empezando en 1.
rownames(df_5) <- sapply(rownames(df_5), function(x) paste("id_", x, sep=""))                 
# b. Cambiar los nombres de las columnas para que cada una se llame
# variable_j siendo j el n�mero de la columna empezando en 1. 
colnames(df_5) <- sapply(colnames(df_5), function(x) paste('variable_', 
                                                           str_sub(x, 2, 2), sep=''))



# 6. Utilizando el dataset pre-existente VADeaths:
# a. Asegurarse de que es un data frame, y si no lo es, convertirlo.
VADeaths <- as.data.frame(VADeaths)
class(VADeaths)
# b. Crear una nueva variable llamada Total que contenga la suma de cada
# fila.
VADeaths$Total <- apply(VADeaths, 1, sum)
# c. Cambiar el orden de las columnas para que Total sea la primera variable.
minusTotal <- names(VADeaths)[!(names(VADeaths) %in% c('Total'))]
sortedColumns <- c('Total', minusTotal)
VADeaths <- VADeaths[sortedColumns]



# 7. Utilizando el dataset pre-existente state.x77:
# a. Asegurarse de que es un data frame, y si no lo es, convertirlo.
state.x77 <- as.data.frame(state.x77) 
is.recursive(state.x77) 
head(state.x77) 
# b. Encontrar cu�ntos estados tienen un ingreso menor que 4300.
nrow(state.x77[state.x77$Income < 4300,]) 
# c. Encontrar el estado con el mayor ingreso
state.x77[state.x77$Income == max(state.x77$Income), ]



# 8. Utilizando el dataset pre-existente swiss, crear un nuevo data frame "swiss2"
# que solamente tenga las filas 1, 2, 3, 10, 11, 12 y 13, y las variables
# Examination, Education e Infant.Mortality.
# a. La mortalidad de Sarine es incorrecta y deber�a ser NA. Modificarla.
is.recursive(swiss) 
swiss2 <- swiss[c(1,2,3,10,11,12,13), c('Examination', 'Education', 'Infant.Mortality')]
swiss2['Sarine', 'Infant.Mortality'] <- NA   
# b. Crear una fila que sea la suma total de la columna, y llamarla Total.
swiss2[nrow(swiss2)+1,] <- apply(swiss2, 2, function(x) sum(x, na.rm=TRUE)) 
rownames(swiss2)[length(rownames(swiss2))] <- 'Total' 
swiss2
# c. Crear una nueva columna que sea la proporci�n de Examination, es decir,
# Examination / Total.
swiss2$ExaminationRatio <- round(swiss2$Examination / swiss2['Total','Examination'], digits=3)



# 9. Crear un data frame con las columnas (variables pre-existentes) state.abb,
# state.area, state.division, state.name y state.region. Los nombres de las filas
# deber�an ser los nombres de los estados.
df <- data.frame(state.abb = state.abb, state.are = state.area, state.division=state.division, 
                 state.name=state.name, state.region=state.region)
rownames(df)=state.name
# a. Renombrar los nombres de columna para que aparezcan solamente las 3
# primeras letras que hay tras el punto. Por ejemplo states.abb se debe
# convertir en abb, state.area en are, state.division en div, etc.
colnames(df) <- sapply(sapply(sapply(colnames(df), function(x) strsplit(x, "\\.")), 
                              function(x) x[2]), 
                       function(x)  str_sub(x,1,3))  



# 10. A�adir el data frame anterior al data frame existente state.x77 por la derecha.
df_10 <- cbind(state.x77, df)
# a. Quitar la columna div
df_10 <- df_10[, !(colnames(df_10) %in% c('div'))]
# b. Quitar tambi�n las variables Life Exp, HS Grad, Frost, abb, and are.
df_10 <- df_10[, !(colnames(df_10) %in% c('Life Exp', 'HS Grad', 'Frost', 'abb', 'are'))]
# c. A�adir una variable nueva que discretice el nivel de illiteracy
# (analfabetismo): [0,1) debe recategorizarse como "bajo", [1,2) como
# "moderado", [2, inf) como "alto".
df_10$level_of_illiteracy <- ifelse(df_10$Illiteracy < 1 , 'low',
                                    ifelse(df_10$Illiteracy < 2, 'medium', 'high'))
# d. Encontrar qu� estado del oeste con bajo analfabetismo tiene los ingresos
# m�s altos, y cu�l es el valor de dichos ingresos
df_slice <- df_10[(df_10$reg=='West') & (df_10$level_of_illiteracy=='low') ,] 
df_slice[df_slice$Income == max(df_slice$Income),]



