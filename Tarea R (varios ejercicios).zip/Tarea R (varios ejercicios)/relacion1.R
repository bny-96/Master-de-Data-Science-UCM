
#Relacion 1. Alumno: PABLO BENAYAS



# 1. Crear un vector llamado "v" que contenga 10 enteros aleatorios entre -100 y
# 100.
as.integer(runif(10, -100, 100)) 



# 2. Crear un array bidimensional 5x5 llamado "a" con los enteros pares mayores
# que 25.
values=seq(from=26, to=26+24*2, by=2)
values=array(values, dim = c(5,5)) 
values



# 3. Crear una lista llamada "s" que contenga 20 letras may�sculas empezando en la
# 'C'. Pista: existe en R una constante ya definida llamada LETTERS.
s <- LETTERS
s <- s[3:(3+19)]
as.list(s) 



# 4. Resolver estas cuestiones:
# a. Crear una lista llamada "l" y poner en ella los tres objetos creados en los
# apartados anteriores. Dentro de la lista deben llamarse "a", "b" y "c"
# respectivamente.
l <- list(a=round(runif(10, -100, 100)), b=values, c=s)
l
# b. �Cu�ntos elementos tiene la lista? �C�mo obtenemos dicho n�mero?
length(l) 
# c. Mostrar la estructura de la lista.
str(l)
# d. Contar recursivamente los elementos (es decir, mostrar cu�ntos
# elementos tiene cada posici�n de la lista, primero mediante un bucle, y
# despu�s sin usar bucles mediante la funci�n sapply).
outcome <- c()
for (element in l) {
  outcome <- c(outcome, length(element)) 
}
outcome
sapply(l, length) 
# e. Reemplazar el elemento "a" de la lista por el resultado de ordenar "a".
l$a <- sort(l$a) 
l



# 5. Sin ejecutar comandos en R, contestar las siguientes preguntas:
# a. �Cu�l es el resultado de l[[3]]? Comprobarlo.
# b. �C�mo podemos acceder a la cuarta letra del elemento "c" de la lista?
# c. �Cu�l ser� el tipo de los elementos si convertimos "l" a un vector?
# Comprobarlo.
# d. �Qu� tipo almacena si la convertimos a un array? Comprobarlo.
  
        #a) devuelve un vector con las letras, (es como poner 'l$c')
        l[[3]]
        
        #b) l$c[4] 
        l$c[4]
        
        #c) Devuelve tipo 'character'
        is.vector(unlist(l)) 
        class(unlist(l))
        
        #d) Devuelve tipo 'array'  
        is.array(array(unlist(l))) 
        class(array(unlist(l))) 




# 6. Eliminar el elemento "c" de la lista anterior, y volver a tratar de convertirla a un
# vector, y comprobar su clase.
l$c = NULL
class(unlist(l))   # -> class numeric



# 7. Calcular:
# a. La diferencia entre los elementos de l[["a"]] menos los de l[["b"]].
l[['a']] - l[['b']] 
# b. La intersecci�n (elementos comunes) entre ambos.
mask <- sapply(l$b, function(x) x %in% l$a) 
l$b[mask]  
# c. �Est� el n�mero 33 en la uni�n de ambos?
      #No



# 8. Crear una matriz 5x5 llamada "m" a partir de datos num�ricos aleatorios
# uniformes redondeados a dos cifras decimales, que est�n entre 1.00 y 100.00.
array(round(runif(5*5, 1, 100), digits=2), dim=c(5,5))  



