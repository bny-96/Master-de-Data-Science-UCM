
#Relacion 4. Alumno: PABLO BENAYAS



library(dplyr)



# 1. Seleccionar las tres primeras columnas del dataset iris usando sus nombres de columna
# uno por uno. 
iris %>% select(c(1:3)) 



# 2. Seleccionar todas las columnas del dataset iris excepto "Petal Width".  
iris %>% select(-Petal.Width) 



# 3. Seleccionar todas las columnas del datdaset iris que empiecen por "P". 
iris %>% select(starts_with('P')) 



# 4. Reemplazar todos los valores de Petal.Width mayores que 3 por NA. 
iris %>% mutate(Petal.Width=ifelse(Petal.Width > 3, NA, Petal.Width)) 



# 5. Quedarse solo con las filas en las que Sepal.Length >= 4.6 y Petal.Width >= 0.5. 
iris %>% filter(Sepal.Length >= 4.6 & Petal.Width >= 0.5) 



# 6. Repetir el ejercicio 5 creando una funci�n a la que le pasemos un dataframe 
# (que siempre ser� el de iris) los dos argumentos correspondientes a los umbrales de 
# Sepal.Length y de Petal.Width: 
# filtrarSepalLengthPetalWidth <- function(df, umbralSepalLength, umbralPetalWidth) y despu�s, 
# invocarla utilizando el operador pipe:  iris %>% filtrarSepalLengthPetalWidth(4.6, 0.5) 

filtrarSepalLengthPetalWidth <- function(dataframe, parameter1, parameter2) {    
  dataframe %>% filter(Sepal.Length >= parameter1 & Petal.Width >= parameter2)
}

iris %>% filtrarSepalLengthPetalWidth(4.6, 0.5) 



# 7. Ordenar el dataset iris ascendentemente por Sepal.Width y en caso de empate, descendemente 
# por Sepal.Length.  
iris %>% arrange(Sepal.Width, desc(Sepal.Length))



# 8. Crear una nueva columna llamada proporcion que sea el cociente de 
# Sepal.Length entre Sepal.Width. 
iris %>% mutate(proporcion=round(Sepal.Length/Sepal.Width, digits=3)) 



# 9. Para cada especie de flor de iris, calcular el n�mero de elementos que hay de esa 
# especie, y la media, m�nimo, m�ximo y desviaci�n t�pica de los cuatro atributos num�ricos.
iris %>% group_by(Species) %>% 
  summarise_all(list(~n(), ~mean(.), ~min(.), ~max(.), ~sd(.))) %>% 
  select(-c('Sepal.Length_n', 'Sepal.Width_n', 'Petal.Length_n')) %>%
  rename(number_of_observations=Petal.Width_n) %>%
  mutate_at(vars(matches("sd")), function(x) round(x, digits=3)) 



