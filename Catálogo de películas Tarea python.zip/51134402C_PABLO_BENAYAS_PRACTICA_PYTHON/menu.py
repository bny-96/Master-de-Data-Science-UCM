from catalogo import *
from pelicula import *


c=Catalogo()
c.agregar(Pelicula('El Señor de los Anillos: El Retorno del Rey',
             201, 2003, 'Peter Jackson', 'Fantasia'))
c.agregar(Pelicula('Ben-Hur', 211, 1959, 'Willian Wyller', 'Aventura'))
c.agregar(Pelicula('Avatar', 161, 2009, 'James Cameron', 'Fantasia'))
c.agregar(Pelicula('Titanic', 195, 1997, 'James Cameron', 'Romance'))
c.agregar(Pelicula('Gladiator', 150, 2000, 'Ridley Scott', 'Accion'))
c.agregar(Pelicula('Braveheart', 177, 1995, 'Mel Gibson', 'Aventura'))
c.agregar(Pelicula('El viaje de Chihiro', 124, 2001, 'Hayao Miyazaki', 'Fantasia'))
c.agregar(Pelicula('Alejandro Magno', 173, 2004, 'Oliver Stone', 'Aventura'))
c.agregar(Pelicula('El ultimo samurai', 144, 2003, 'Edward Zwick', 'Aventura'))
c.agregar(Pelicula('Los chicos del coro', 95, 2004, 'Christophe Barratier', 'Drama'))


print('\n MENU ')
print('='*6)
print('''
1: Mostrar todo el catalogo de peliculas
2: Mostrar peliculas por genero
3: Añadir pelicula nueva
4: Eliminar pelicula
5: Salir

''')

while True:
    try:
        valor=int(input('INSTRUCCIONES: inserte un numero del 1 al 5 (ambos incluidos): '))
        while valor not in [1,2,3,4,5] and str(valor).isnumeric():
            valor=int(input('Numero insertado fuera de rango. Intentelo de nuevo: '))
        else:
            break
    except ValueError:
        print('''Ha insertado una cadena de caracters que no es numerica.
Por favor, inserte un numero dentro de ese rango''')

import sys
while valor != 5:
    if valor == 1:
        # print(c.mostrar())
        c.mostrar()

    if valor == 2:
        # print(c.generos_disponibles())
        c.generos_disponibles()

        genero=input('Inserte uno de los generos disponibles: ')
        while genero.isnumeric():
            genero=input('''No inserte el numero, inserte la palabra: ''')
        while genero not in c.lista_generos_disponibles():
            genero=input('''La palabra insertada no esta incluida.
Asegurate que has escrito la primera letra en mayusculas: ''')
        # print(c.mostrar_por_genero(genero))
        c.mostrar_por_genero(genero)

    if valor == 3:
        titulo=input('Inserte el titulo de la nueva pelicula:')
        while titulo.isnumeric():
            titulo=input('''Valor numerico insertado no valido. Intentelo de nuevo: ''')

        duracion=input('duracion en minutos (inserte solo el numero)')
        while not duracion.isnumeric() or len(duracion) > 3:
            duracion=input('''Ha insertado una cadena de caracters que no es numerica o el numerco insertado
            es muy largo (max 3 digitos). Intentelo de nuevo: ''')

        lanzamiento=input('introduzca el año de lanzamiento: ')
        while not lanzamiento.isnumeric() or int(lanzamiento) not in range(1900,2020):
            lanzamiento=input('''Ha insertado una cadena de caracters que no es numerica o el numero insertado
            no esta en el rango (1900-2019). Intentelo de nuevo: ''')

        director=input('introduzca el nombre del director: ')
        while director.isnumeric():
            director=input('''Valor numerico insertado no valido. Intentelo de nuevo: ''')

        genero=input('introduzca el genero de la pelicula: ')
        while genero.isnumeric():
            genero=input('''Valor numerico insertado no valido. Intentelo de nuevo: ''')

        nueva_pelicula=Pelicula(titulo, int(duracion), int(lanzamiento), director, genero)
        c.agregar(nueva_pelicula)

    if valor == 4:
        # print(c.mostrar())
        c.mostrar()
        num_pelicula=input('Introduzca el numero de pelicula que desea borrar: ')
        # count = 0
        while (not num_pelicula.isnumeric()) or (int(num_pelicula) not in range(len(c.lista))):
            num_pelicula=input('''valor insertado no es numerico o esta fuera del rango de numeros del Catalogo.
            Intentelo de nuevo: ''')

        # print(c.borrar(int(num_pelicula)))
        c.borrar(int(num_pelicula))



    print('''\n     MENU
    ======
    1: Mostrar todo el catalogo de peliculas
    2: Mostrar peliculas por genero
    3: Añadir pelicula nueva
    4: Eliminar pelicula
    5: Salir
    ''')
    # valor=int(input('''Introduzca de nuevo un numero del 1 al 5 (ambos incluidos.
    # El programa terminara cuando el usuario inserte '5'): '''))


    while True:
        try:
            valor=int(input('''INSTRUCCIONES: inserte un numero del 1 al 5 (ambos incluidos).
            El programa terminara cuando el usuario inserte '5'): '''))
            while (valor not in [1,2,3,4,5]) and (str(valor).isnumeric()):
                valor=int(input('Numero insertado fuera de rango. Intentelo de nuevo: '))
            else:
                break
        except ValueError:
            print('''\n Ha insertado una cadena de caracters que no es numerica.
    Por favor, inserte un numero dentro de ese rango''')





print('El programa ha terminado. ¡Adios!')

sys.exit()
