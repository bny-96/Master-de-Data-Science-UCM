class Pelicula:
    def __init__(self, titulo, duracion, lanzamiento, director, genero):
        self.titulo=titulo
        self.duracion=duracion
        self.lanzamiento=lanzamiento
        self.director=director
        self.genero=genero
        print('Se ha creado la pelicula: {}'.format(self.titulo))

    def __str__(self):
        return '\t{} ({}, {} - {})'.format(self.titulo,self.lanzamiento,self.director,self.genero)
