class Catalogo:
    def __init__(self, listaPeliculas=[]):
        self.lista=listaPeliculas

    def agregar(self, pelicula):
        return self.lista.append(pelicula)

    def borrar(self, num_pelicula):
        print('{} ha sido borrada del catalogo'.format(self.lista[num_pelicula]))
        for index, element in enumerate(self.lista):
            if index==num_pelicula:
                del(self.lista[index])

    def mostrar(self):
        print('\n\nLista de peliculas existentes')
        for index, element in enumerate(self.lista):
            print('\t{}. {}'.format(index ,element))

    def generos_disponibles(self):
        generos=[]
        for element in self.lista:
            generos.append(element.genero)

        generos_unique=[]
        for genero in generos:
            if genero not in generos_unique:
                generos_unique.append(genero)
        print('''Generos disponibles:''')
        for index, genero in enumerate(generos_unique):
            print('\t{}. {}'.format(index, genero))

    def lista_generos_disponibles(self):
        generos=[]
        for element in self.lista:
            generos.append(element.genero)

        generos_unique=[]
        for genero in generos:
            if genero not in generos_unique:
                generos_unique.append(genero)
        return generos_unique

    def mostrar_por_genero(self, genero):
        generos=[]
        for element in self.lista:
            generos.append(element.genero)

        generos_unique=[]
        for gen in generos:
            if gen not in generos_unique:
                generos_unique.append(gen)

        print('\n\nLista de peliculas de genero: {}'.format(genero))
        for element in self.lista:
            if element.genero == genero:
                print('{}'.format(element))
